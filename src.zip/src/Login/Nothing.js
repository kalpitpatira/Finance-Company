import React, { Component } from 'react';
class Nothing extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( <div></div> );
    }
}
 
export default Nothing;