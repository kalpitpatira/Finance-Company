import React from "react";

class Header extends React.Component{

    render(){

        return(
            <div>
                <h2>Ganesh Finance Compnay Limited</h2>
            </div>
        )
    }
}
export default Header;